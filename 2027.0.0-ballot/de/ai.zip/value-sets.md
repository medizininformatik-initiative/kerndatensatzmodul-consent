# ValueSets - MII Implementation Guide Consent v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* **ValueSets**

## ValueSets

### ValueSets

Diese Seite beschreibt die ValueSets des Moduls **Consent**; die zugrunde liegenden CodeSystems beschreibt die Seite [CodeSystems](code-systems.md).

### MII_VS_Consent_Policy

Erweiterungen des PolicyValueSets im ART-DECOR werden zeitnah durch die TFCU in diesem IG eingepflegt. Eine erneute Ballotierung ist nicht erforderlich.

Siehe die Artefaktseite [MII_VS_Consent_Policy](ValueSet-mii-vs-consent-policy.md).

### mii-vs-consent-signaturetypes

Gemäß HL7-D AG Einwilligungsmanagement-Empfehlung

Kanonische URL: `https://www.medizininformatik-initiative.de/fhir/modul-consent/ValueSet/mii-vs-consent-signaturetypes` — siehe die Artefaktseite [MII_VS_Consent_SignatureTypes](ValueSet-mii-vs-consent-signaturetypes.md).

| | | | |
| :--- | :--- | :--- | :--- |
| Unterschrift der einwilligenden Person | urn:iso-astm:E1762-95:2013 | 1.2.840.10065.1.12.1.7 | Consent Signature |
| Unterschrift der (gesetzlich) vertretenden Person | urn:iso-astm:E1762-95:2013 | 1.2.840.10065.1.12.1.11 | Consent Witness Signature |
| Unterschrift der aufklärenden Person | urn:iso-astm:E1762-95:2013 | 1.2.840.10065.1.12.1.5 | Verification Signature |

### mii-vs-consent-answer

Dieses ValueSet findet ausschließlich im Kontext von Questionnaires Verwendung.

Siehe die Artefaktseite [mii-vs-consent-answer](ValueSet-mii-vs-consent-answer.md).

