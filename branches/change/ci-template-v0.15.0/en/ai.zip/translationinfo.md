# Translation Information - MII Implementation Guide Consent v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* **Translation Information**

## Translation Information

This page includes translations from the original source language in which the guide was authored. Information on these translations and instructions on how to provide feedback on the translations can be found [here](translationinfo.md).

This guide is written in **German** (the default language); **English** is the translation. German is therefore both the base rendering of the guide and the `/de/` rendering; use the language switcher at the top right to move between `/de/` and `/en/`.

Translated pages live under `input/translations/en/pagecontent/` (same file name as the German page); resource translations are `.po` files under `input/translations/en/`. Details: [`docs/recipes/add-translation.md`](https://github.com/medizininformatik-initiative/kerndatensatzmodul-consent/blob/main/docs/recipes/add-translation.md) in this repository.

All guide pages of this module exist as **machine-translated English versions** of the German source pages (migration state 2026-08-31; expert review of the translations is ongoing). The resource titles are translated by the IG-level catalogue `input/translations/en/ImplementationGuide-mii-ig-consent.po`.

