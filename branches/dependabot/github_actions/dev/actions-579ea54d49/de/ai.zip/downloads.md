# Downloads - MII Implementation Guide Consent v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* **Downloads**

## Downloads

Diese Seite verlinkt die herunterladbaren Artefakte des Moduls **Consent**.

#### Paketdatei

Die Paketdatei ist ein FHIR-Paket im NPM-Format, wie es die meisten FHIR-Werkzeuge verwenden. Sie enthält alle ValueSets, Profile, Extensions sowie die Liste der Seiten und URLs dieses Leitfadens in dieser Version. Sie SOLLTE die erste Wahl sein, wann immer Implementierungsartefakte erzeugt werden, denn sie trägt alle Regeln, die die Profile gültig machen. Implementierende müssen darüber hinaus den Inhalt der Spezifikation und die einschlägigen Profile kennen, um eine konforme Umsetzung zu bauen — siehe die FHIR-Dokumentation zur [Validierung von Profilen und Ressourcen](http://hl7.org/fhir/R4/validation.html).

* [Paket (komprimierter Ordner)](../package.tgz)

#### Herunterladbare Kopie dieses Leitfadens

Eine herunterladbare Fassung des gerenderten Leitfadens für den lokalen Betrieb:

* [Herunterladbare Kopie (komprimierter Ordner)](../full-ig.zip)

#### Beispiele

Alle Beispiele dieses Leitfadens:

* [XML (komprimierter Ordner)](../examples.xml.zip)
* [JSON (komprimierter Ordner)](../examples.json.zip)

#### Konsolidierte CSV- und Excel-Darstellungen der Profile

Die Profilinformationen des gesamten Leitfadens in einer einzigen CSV- oder Excel-Datei — nützlich für Testende und Analysierende, die Element-Eigenschaften profilübergreifend in einer Tabelle sichten wollen:

* [CSV (komprimierter Ordner)](../csvs.zip)
* [Excel (komprimierter Ordner)](../excels.zip)

#### Schematrons

* [Schematrons (komprimierter Ordner)](../schematrons.zip)

#### ImplementationGuide-Ressource

Die `ImplementationGuide`-Ressource trägt die technischen Details dieser Veröffentlichung einschließlich ihrer Abhängigkeiten und Veröffentlichungsparameter.

Siehe die Seite [MII ImplementationGuide Ressource](ImplementationGuide-mii-ig-consent.md).

#### Versionshistorie

Frühere Versionen und die ausführliche Änderungshistorie stehen auf den Seiten [Versionierung](version-history.md) und [Änderungshistorie](changes.md).

