# Value Sets - MII Implementation Guide Consent v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* **Value Sets**

## Value Sets

### ValueSets

This page describes the ValueSets of the **Consent** module; the underlying CodeSystems are described on the [CodeSystems](code-systems.md) page.

### MII_VS_Consent_Policy

Extensions of the Policy ValueSet in ART-DECOR are incorporated into this IG by the TFCU in a timely manner. A renewed ballot is not required.

See the artifact page [MII_VS_Consent_Policy](ValueSet-mii-vs-consent-policy.md).

### mii-vs-consent-signaturetypes

In accordance with the recommendation of the HL7-D AG Einwilligungsmanagement

Canonical URL: `https://www.medizininformatik-initiative.de/fhir/modul-consent/ValueSet/mii-vs-consent-signaturetypes` — see the artifact page [MII_VS_Consent_SignatureTypes](ValueSet-mii-vs-consent-signaturetypes.md).

| | | | |
| :--- | :--- | :--- | :--- |
| Signature of the consenting person | urn:iso-astm:E1762-95:2013 | 1.2.840.10065.1.12.1.7 | Consent Signature |
| Signature of the (legally) representing person | urn:iso-astm:E1762-95:2013 | 1.2.840.10065.1.12.1.11 | Consent Witness Signature |
| Signature of the informing person | urn:iso-astm:E1762-95:2013 | 1.2.840.10065.1.12.1.5 | Verification Signature |

### mii-vs-consent-answer

This ValueSet is used exclusively in the context of Questionnaires.

See the artifact page [mii-vs-consent-answer](ValueSet-mii-vs-consent-answer.md).

