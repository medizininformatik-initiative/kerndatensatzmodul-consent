# 8a3d1799-2463-405e-b49c-6a16c8692b01 - MII Implementation Guide Consent v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **8a3d1799-2463-405e-b49c-6a16c8692b01**

## Beispiel DocumentReference: 8a3d1799-2463-405e-b49c-6a16c8692b01

-------

**German**

-------

Last updated: 2020-12-11 09:09:07+0000

Profile: [Profile - MI-I - Consent - DocumentReference](StructureDefinition-mii-pr-consent-documentreference.md)

**status**: Current

**subject**: [Anonymous Patient (no stated gender), DoB Unknown ( Anonymous identifier: MII-CONSENT-TESTPSN-0001)](Patient-9b4a702d-162c-428a-8c5d-8b98af21b693.md)

> **content**

### Attachments

| | | |
| :--- | :--- | :--- |
| - | **ContentType** | **Data** |
| * | pdf | `YmFzZTY0Q29kaWVydGVzUERGRGVzVW50ZXJzY2hyaWViZW5lblBhdGllbnRlbkVpbndpbGxpZ3VuZ3Nib2dlbnM=` |




## Resource Content

```json
{
  "resourceType" : "DocumentReference",
  "id" : "8a3d1799-2463-405e-b49c-6a16c8692b01",
  "meta" : {
    "lastUpdated" : "2020-12-11T09:09:07.5320994+00:00",
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/modul-consent/StructureDefinition/mii-pr-consent-documentreference"]
  },
  "status" : "current",
  "subject" : {
    "reference" : "Patient/9b4a702d-162c-428a-8c5d-8b98af21b693"
  },
  "content" : [{
    "attachment" : {
      "contentType" : "application/pdf",
      "data" : "YmFzZTY0Q29kaWVydGVzUERGRGVzVW50ZXJzY2hyaWViZW5lblBhdGllbnRlbkVpbndpbGxpZ3VuZ3Nib2dlbnM="
    }
  }]
}

```
