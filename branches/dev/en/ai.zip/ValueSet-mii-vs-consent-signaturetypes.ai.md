# MII Consent: Signature Types - MII Implementation Guide Consent v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MII Consent: Signature Types**

## ValueSet: MII Consent: Signature Types 

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/modul-consent/ValueSet/mii-vs-consent-signaturetypes | *Version*:2027.0.0-ballot |
| Active as of 2025-12-03 | *Computable Name*:MII_VS_Consent_SignatureTypes |

 
Dieses ValueSet enthält die zulässigen Werte für den Signaturtyp im Kontext des MI-I Consent. 

 **References** 

* [Profile - MI-I - Consent - Provenance](StructureDefinition-mii-pr-consent-provenance.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "mii-vs-consent-signaturetypes",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablevalueset"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/resource-effectivePeriod",
    "valuePeriod" : {
      "start" : "2022-02-11T10:27:00+01:00"
    }
  }],
  "url" : "https://www.medizininformatik-initiative.de/fhir/modul-consent/ValueSet/mii-vs-consent-signaturetypes",
  "version" : "2027.0.0-ballot",
  "name" : "MII_VS_Consent_SignatureTypes",
  "title" : "MII Consent: Signature Types",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-12-03",
  "publisher" : "NUM-DIZ",
  "_publisher" : {
    "extension" : [{
      "extension" : [{
        "url" : "lang",
        "valueCode" : "en"
      },
      {
        "url" : "content",
        "valueString" : "NUM-DIZ"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/translation"
    }]
  },
  "contact" : [{
    "name" : "NUM-DIZ",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.netzwerk-universitaetsmedizin.de"
    }]
  }],
  "description" : "Dieses ValueSet enthält die zulässigen Werte für den Signaturtyp im Kontext des MI-I Consent.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "immutable" : false,
  "compose" : {
    "include" : [{
      "system" : "urn:iso-astm:E1762-95:2013",
      "concept" : [{
        "code" : "1.2.840.10065.1.12.1.7",
        "display" : "Consent Signature"
      },
      {
        "code" : "1.2.840.10065.1.12.1.11",
        "display" : "Consent Witness Signature"
      },
      {
        "code" : "1.2.840.10065.1.12.1.5",
        "display" : "Verification Signature"
      }]
    }]
  }
}

```
