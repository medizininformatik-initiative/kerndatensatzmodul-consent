<!-- machine translation of source page StructureDefinition-mii-pr-consent-provenance-intro.md (de). -->
<!-- Wortgetreu übertragen aus der Simplifier-Quellseite
     https://simplifier.net/guide/miiigmodulconsent/MIIIGModulConsent/TechnischeImplementierung/FHIRProfile/Provenance?version=2026.0.0
     (Harvest 2026-08-31); Links umgeschrieben (page-map). -->
<!-- Der gerenderte Abschnitt "Darstellung" wird vom IG Publisher neu erzeugt;
     Abschnitt "Beispiele": siehe Seite Beispiele (der XML-Render der Quellseite
     war dort defekt — "Command 'xml' could not render", Gate-B-Befund). -->
Based on the [recommendations](https://ig.fhir.de/einwilligungsmanagement/stable/Provenance.html) of the AG Einwilligungsmanagement, the profile *MIIConsentProvenance* describes the provenance information of a consent document.

<!-- Completion 2026-09-04 (fresh migration onto release 2027.0.0-ballot.rc1):
     the source page's "Differences to the base profile" table was dropped
     together with the "Darstellung" section in the 2026 migration — added
     here (harvest content, tables normalized). -->
*Only the differences to the [base profile](https://ig.fhir.de/einwilligungsmanagement/stable/Provenance.html) are explained below.*

| **FHIR element** | **Explanation** |
| --- | --- |
| Provenance.entity.what | If a document scan is to be attached, the referenced resource must be of the profile type [DocumentReference](StructureDefinition-mii-pr-consent-documentreference.html), Must-support |
| Provenance.entity.signature.type | If a base64-encoded signature is to be attached, the type of the signature must follow [MII\_VS\_Consent\_SignatureTypes](ValueSet-mii-vs-consent-signaturetypes.html), Must-support |
